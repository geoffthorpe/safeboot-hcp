#!/bin/bash

/startpulse.sh &
(
if [[ -x /chosen-wm ]]; then
	/chosen-wm
else
	/usr/bin/mate-session
fi
) > $HOME/log-startwm 2>&1
